@echo off
call "%~dp0INICIAR_JOGO.bat" --teste
