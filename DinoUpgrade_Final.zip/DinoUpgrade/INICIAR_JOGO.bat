@echo off
setlocal
cd /d "%~dp0"
title Dino Upgrade

set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (
  where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo Python nao encontrado.
  echo Instale em https://www.python.org/downloads/ e marque Add Python to PATH.
  pause
  exit /b 1
)

%PY% -c "import pygame" >nul 2>&1
if errorlevel 1 (
  echo Instalando o Pygame ^(necessita de internet^)...
  %PY% -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Falha ao instalar as dependencias. Verifique o Python e a internet.
    pause
    exit /b 1
  )
)

%PY% main.py %*
if errorlevel 1 (
  echo.
  echo O jogo encontrou um erro. Veja a mensagem acima.
  pause
)
endlocal
